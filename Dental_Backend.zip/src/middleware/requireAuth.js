const { ClerkExpressRequireAuth } = require('@clerk/clerk-sdk-node');
const requireAuth = ClerkExpressRequireAuth();
module.exports = requireAuth;